const api = require('../../utils/api');

Page({
  data: {
    title: '',
    matchResult: [],
    addrQuery: '',
    sugs: [],
    submitting: false,
    showAddrPicker: false,
    addrGroups: [],
    _allLocs: [],
    _selectedBuilding: '',
    _selectedFloor: '',
    _selectedLocation: '',
    _selectedDept: '',
  },

  onLoad() {
    this._loadAddresses();
  },

  _loadAddresses() {
    var that = this;
    wx.request({
      url: 'https://demolin.cn/api/mobile/addresses',
      success: (res) => {
        if (res.data && res.data.locations && res.data.locations.length > 0) {
          that.data._allLocs = res.data.locations;
          var groups = that._groupByBuilding(res.data.locations);
          that.data.addrGroups = groups;
          that.setData({ addrGroups: groups });
        }
      },
    });
  },

  _groupByBuilding(locs) {
    var map = {};
    locs.forEach(function(a) {
      var b = a.building || '其他';
      if (!map[b]) map[b] = [];
      map[b].push(a);
    });
    var groups = [];
    Object.keys(map).sort().forEach(function(b) {
      groups.push({ building: b, items: map[b] });
    });
    return groups;
  },

  // 输入工单名称 → 实时自动识别
  onInput(e) {
    var title = e.detail.value;
    this.setData({ title: title, matchResult: [] });
    if (!title.trim()) return;

    wx.request({
      url: 'https://demolin.cn/api/mobile/guess?title=' + encodeURIComponent(title),
      success: (res) => {
        var d = res.data || {};
        var tags = [];
        if (d.fault) tags.push('🔧 ' + d.fault);
        if (d.building) tags.push('🏢 ' + d.building);
        if (d.department) tags.push('🚪 ' + d.department);
        this.setData({ matchResult: tags });
        // 实时自动填入地址
        if (d.building) {
          this.setData({
            _selectedBuilding: d.building || '',
            _selectedFloor: d.floor || '',
            _selectedDept: d.department || '',
            _selectedLocation: d.location || '',
          });
        }
      },
    });
  },

  // 地址搜索联想
  onAddrQuery(e) {
    var q = e.detail.value;
    this.setData({ addrQuery: q });
    if (!q) { this.setData({ sugs: [] }); return; }

    var ql = q.toLowerCase();
    var pool = this.data._allLocs.filter(function(a) {
      return a.location.toLowerCase().indexOf(ql) >= 0 ||
             (a.department && a.department.toLowerCase().indexOf(ql) >= 0) ||
             a.building.toLowerCase().indexOf(ql) >= 0;
    });
    var seen = {};
    pool = pool.filter(function(a) {
      var k = a.building + '|' + a.floor + '|' + a.location;
      if (seen[k]) return false;
      seen[k] = true;
      return true;
    });
    this.setData({ sugs: pool.slice(0, 50) });
  },

  onAddrFocus() {
    if (this.data.addrQuery) {
      this.onAddrQuery({ detail: { value: this.data.addrQuery } });
    }
  },

  onSelectAddr(e) {
    this._selectItem(e.currentTarget.dataset.item);
  },

  onOpenAddrPicker() {
    var groups = this.data.addrGroups;
    if (groups.length === 0 && this.data._allLocs.length > 0) {
      groups = this._groupByBuilding(this.data._allLocs);
      this.data.addrGroups = groups;
    }
    this.setData({ showAddrPicker: true, addrGroups: groups, sugs: [] });
  },

  onCloseAddrPicker() {
    this.setData({ showAddrPicker: false });
  },

  onSelectFromPicker(e) {
    var item = e.currentTarget.dataset.item;
    this._selectItem(item);
    this.setData({ showAddrPicker: false });
  },

  _selectItem(item) {
    this.setData({
      _selectedBuilding: item.building,
      _selectedFloor: item.floor || '',
      _selectedLocation: item.location,
      _selectedDept: item.department || '',
      addrQuery: item.location,
      sugs: [],
    });
  },

  onClearAddr() {
    this.setData({
      _selectedBuilding: '',
      _selectedFloor: '',
      _selectedLocation: '',
      _selectedDept: '',
      addrQuery: '',
    });
  },

  onSubmit() {
    var title = this.data.title.trim();
    if (!title) {
      wx.showToast({ title: '请输入工单名称', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });

    api.createOrder({
      title: title,
      building: this.data._selectedBuilding,
      floor: this.data._selectedFloor,
      department: this.data._selectedDept,
      location: this.data._selectedLocation,
      priority: 'normal',
    }).then(() => {
      wx.showToast({ title: '✅ 已发布', icon: 'success' });
      setTimeout(function() { wx.navigateBack(); }, 800);
    }).catch((err) => {
      this.setData({ submitting: false });
      wx.showToast({ title: (err && err.error) || '发布失败', icon: 'none' });
    });
  },
});
